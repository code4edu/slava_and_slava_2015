<!DOCTYPE html>
<html lang="ru-Ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Закажи еду в два клика и забери в столовой без очереди! Поедим</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Поедим">
    <meta name="description" content="Поедим">
    <link type="image/ico" href="/img/favicon.ico" rel="shortcut icon"/>
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/jquery.js" type="text/javascript"></script>
    <link type="image/ico" href="/img/favicon.ico" rel="shortcut icon"/>
    <link rel="stylesheet" href="/css/style.css">

    <script src="/js/site.js" type="text/javascript"></script>
</head>