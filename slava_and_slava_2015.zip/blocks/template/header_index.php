    <header>
        <div class="containder">
            <img src="img/headerLogo.png" />
            <p>Закажи еду в два клика и забери в столовой без очереди!</p>
        </div>
    </header>