    <header>
        <div class="containder">
            <a href="/"><img src="img/headerLogo.png" alt="Поедим"/></a>
            <p>Закажи еду в два клика и забери в столовой без очереди!</p>
        </div>
    </header>