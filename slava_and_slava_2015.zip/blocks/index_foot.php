<?
#poedim.csit.pro list of catalog

if(!defined("SITE_POEDIM_SECURE"))
    die("Access denied");
?>
    <footer>
        <a href="/?page=cart">Перейти в корзину</a>
    </footer>