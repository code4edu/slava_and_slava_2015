<form name="auto" method="POST" action="https://money.yandex.ru/quickpay/confirm.xml">
	<input type="hidden" name="receiver" value="41001431548759">
	<input type="hidden" name="formcomment" value="POEDIM.CSIT.PRO">
	<input type="hidden" name="short-dest" value="За шаверму с мяском">
	<input type="hidden" name="label" value="1">
	<input type="hidden" name="quickpay-form" value="shop">
	<input type="hidden" name="targets" value="заказ номер 1">
	<input type="hidden" name="sum" value="500" data-type="number">
	<input type="hidden" name="paymentType" value="AC"/>
</form>
<script language="JavaScript">
	document.forms["auto"].submit();
</script>
<noscript>
	<section>
		<p>Наименование платежа: За шаверму с мяском</p>
		<p>Сумма: 500 руб.</p>
		<form action="" method="post">
			<input type="hidden" name="receiver" value="41001431548759">
			<input type="hidden" name="formcomment" value="POEDIM.CSIT.PRO">
			<input type="hidden" name="short-dest" value="За шаверму с мяском">
			<input type="hidden" name="label" value="1">
			<input type="hidden" name="quickpay-form" value="shop">
			<input type="hidden" name="targets" value="заказ номер 1">
			<input type="hidden" name="sum" value="500" data-type="number">
			<input type="hidden" name="paymentType" value="AC"/>
		</form>
	</section>
</noscript>