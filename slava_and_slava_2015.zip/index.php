<?php
#poedim.csit.pro
#fast and tasty food in SSU

define("SITE_POEDIM_SECURE", "yes");
include('blocks/core.php');

